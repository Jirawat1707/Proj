from django.urls import path
from . import views

urlpatterns = [
     path('', views.index, name='index'),
     path('about', views.about, name='about'),
     path('contact', views.contact, name='contact'),
     path('run', views.run, name='run'),
     path('a1_2560', views.a1_2560, name='a1_2560'),
     path('a2_2560', views.a2_2560, name='a2_2560'),
     path('com1_2561', views.com1_2561, name='com1_2561'),
     path('com2_2561', views.com2_2561, name='com2_2561'),
     path('com1_2562', views.com1_2562, name='com1_2562'),
     path('com2_2562', views.com2_2562, name='com2_2562'),
     path('ele1_2561', views.ele1_2561, name='ele1_2561'),
     path('ele2_2561', views.ele2_2561, name='ele2_2561'),
     path('ele1_2562', views.ele1_2562, name='ele1_2562'),
     path('ele2_2562', views.ele2_2562, name='ele2_2562'),
     path('tel1_2561', views.tel1_2561, name='tel1_2561'),
     path('tel2_2561', views.tel2_2561, name='tel2_2561'),
     path('tel1_2562', views.tel1_2562, name='tel1_2562'),
     path('tel2_2562', views.tel2_2562, name='tel2_2562')
]